<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyright &copy; 2020</strong>
	  <br>
	  <strong> Brought to You By Darsh Patel and Hewitt Kothari</strong>
    </div>
</footer>